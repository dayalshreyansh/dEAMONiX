def extract_fields(self, text: str):

    prompt = f"""
You are an expert banking document parser.

Extract ALL useful fields.

Rules:

1. Return ONLY JSON.

2. Missing fields should be null.

3. Never explain.

Return format:

{{
    "name": null,
    "dob": null,
    "gender": null,
    "aadhaar_number": null,
    "pan_number": null,
    "passport_number": null,
    "account_number": null,
    "bank_name": null,
    "ifsc": null,
    "gross_salary": null,
    "tax": null,
    "net_salary": null,
    "company_name": null,
    "address": null
}}

Document:

{text}
"""

    response = self._generate(prompt)

    return json.loads(response)