from models.pdf_data import PDFData


class ClassifierService:

    def process(self, pdf: PDFData) -> PDFData:

        text = pdf.ocr_text.lower()

        document_type = "UNKNOWN"
        confidence = 0.0

        # -----------------------
        # Aadhaar
        # -----------------------

        if any(word in text for word in [
            "uidai",
            "aadhaar",
            "government of india",
            "enrolment"
        ]):

            document_type = "AADHAAR"
            confidence = 0.98

        # -----------------------
        # PAN
        # -----------------------

        elif any(word in text for word in [
            "permanent account number",
            "income tax department",
            "pan"
        ]):

            document_type = "PAN"
            confidence = 0.97

        # -----------------------
        # Bank Statement
        # -----------------------

        elif any(word in text for word in [
            "statement",
            "account number",
            "closing balance",
            "transaction"
        ]):

            document_type = "BANK_STATEMENT"
            confidence = 0.95

        # -----------------------
        # Payslip
        # -----------------------

        elif any(word in text for word in [
            "salary",
            "gross pay",
            "net pay",
            "deduction"
        ]):

            document_type = "PAYSLIP"
            confidence = 0.95

        pdf.document_type = document_type
        pdf.classification_confidence = confidence

        return pdf