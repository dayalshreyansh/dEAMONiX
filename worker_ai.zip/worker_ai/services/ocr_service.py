try:
    import easyocr
except ImportError:
    easyocr = None

from config import OCR
from models.pdf_data import PDFData


class OCRService:

    def __init__(self):

        self.reader = None

        if easyocr is not None:
            self.reader = easyocr.Reader(
                OCR.language,
                gpu=False
            )

    def process(self, pdf: PDFData) -> PDFData:
        """
        Extract text if native PDF text is insufficient.
        """

        native_text = pdf.text.strip()

        # Native PDF already contains selectable text.
        if len(native_text) > 20:
            pdf.ocr_text = native_text
            return pdf

        # No OCR engine available.
        if self.reader is None:
            pdf.ocr_text = native_text
            return pdf

        try:

            results = self.reader.readtext(
                pdf.image,
                detail=0
            )

            pdf.ocr_text = " ".join(results)

        except Exception as e:

            print(f"OCR Error : {e}")

            pdf.ocr_text = native_text

        return pdf