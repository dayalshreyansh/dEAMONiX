"""
tamper_service.py

Performs image forensic analysis.

Current Version
---------------
✓ Error Level Analysis (ELA)

Future
------
✓ CNN Forgery Detector
✓ Vision Transformer
✓ Ensemble Fraud Detection
"""

import os
import uuid

import cv2
import numpy as np

from config import AI
from models.pdf_data import PDFData


class TamperService:

    def process(self, pdf: PDFData) -> PDFData:

        print("\n🔍 Running Image Forensics...")

        image = pdf.image

        temp_file = f"temp_{uuid.uuid4().hex}.jpg"

        try:

            # ------------------------------------
            # Step 1
            # JPEG Compression
            # ------------------------------------

            cv2.imwrite(
                temp_file,
                image,
                [cv2.IMWRITE_JPEG_QUALITY, 90]
            )

            compressed = cv2.imread(temp_file)

            # ------------------------------------
            # Step 2
            # Difference Map
            # ------------------------------------

            difference = cv2.absdiff(
                image,
                compressed
            )

            # ------------------------------------
            # Step 3
            # Statistical Score
            # ------------------------------------

            _, std = cv2.meanStdDev(
                difference
            )

            score = float(std[0][0] * 10)

            score = max(
                0,
                min(score, 100)
            )

            pdf.tamper_score = score

            # ------------------------------------
            # Step 4
            # Heatmap
            # ------------------------------------

            gray = cv2.cvtColor(
                difference,
                cv2.COLOR_BGR2GRAY
            )

            _, heatmap = cv2.threshold(
                gray,
                12,
                255,
                cv2.THRESH_BINARY
            )

            proof_folder = "proofs"

            os.makedirs(
                proof_folder,
                exist_ok=True
            )

            filename = f"{uuid.uuid4().hex}.png"

            heatmap_path = os.path.join(
                proof_folder,
                filename
            )

            cv2.imwrite(
                heatmap_path,
                heatmap
            )

            pdf.heatmap_path = heatmap_path

            print(
                f"✅ Tamper Score : {score:.2f}"
            )

            return pdf

        finally:

            if os.path.exists(temp_file):

                os.remove(temp_file)