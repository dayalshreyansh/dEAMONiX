"""
validation_service.py

Validates information extracted by the AI.

Responsibilities
----------------

✓ Aadhaar checksum
✓ PAN validation
✓ Salary validation
✓ Required fields
"""

import re

from models.pdf_data import PDFData


# -----------------------------
# Verhoeff Tables
# -----------------------------

verhoeff_d = (
    (0,1,2,3,4,5,6,7,8,9),
    (1,2,3,4,0,6,7,8,9,5),
    (2,3,4,0,1,7,8,9,5,6),
    (3,4,0,1,2,8,9,5,6,7),
    (4,0,1,2,3,9,5,6,7,8),
    (5,9,8,7,6,0,4,3,2,1),
    (6,5,9,8,7,1,0,4,3,2),
    (7,6,5,9,8,2,1,0,4,3),
    (8,7,6,5,9,3,2,1,0,4),
    (9,8,7,6,5,4,3,2,1,0)
)

verhoeff_p = (
    (0,1,2,3,4,5,6,7,8,9),
    (1,5,7,6,2,8,3,0,9,4),
    (5,8,0,3,7,9,6,1,4,2),
    (8,9,1,6,0,4,3,5,2,7),
    (9,4,5,3,1,2,6,8,7,0),
    (4,2,8,6,5,7,3,9,0,1),
    (2,7,9,3,8,0,6,4,1,5),
    (7,0,4,6,9,1,3,2,5,8)
)


def validate_aadhaar(number):

    c = 0

    number = str(number)[::-1]

    for i, digit in enumerate(number):

        c = verhoeff_d[c][verhoeff_p[i % 8][int(digit)]]

    return c == 0


class ValidationService:

    def process(self, pdf: PDFData):

        fields = pdf.extracted_fields

        pdf.validation_status = "GREEN"
        pdf.validation_reason = "Validation Passed"

        # -------------------------
        # Aadhaar Validation
        # -------------------------

        aadhaar = fields.get("aadhaar_number")

        if aadhaar:

            aadhaar = aadhaar.replace(" ", "")

            if not validate_aadhaar(aadhaar):

                pdf.validation_status = "RED"

                pdf.validation_reason = \
                    "Invalid Aadhaar checksum"

                return pdf

        # -------------------------
        # PAN Validation
        # -------------------------

        pan = fields.get("pan_number")

        if pan:

            pattern = r"[A-Z]{5}[0-9]{4}[A-Z]"

            if not re.fullmatch(pattern, pan.upper()):

                pdf.validation_status = "RED"

                pdf.validation_reason = \
                    "Invalid PAN format"

                return pdf

        # -------------------------
        # Salary Validation
        # -------------------------

        gross = fields.get("gross_salary")
        tax = fields.get("tax")
        net = fields.get("net_salary")

        try:

            if gross and tax and net:

                gross = float(gross)

                tax = float(tax)

                net = float(net)

                if abs((gross - tax) - net) > 1:

                    pdf.validation_status = "RED"

                    pdf.validation_reason = \
                        "Salary calculation mismatch"

                    return pdf

        except:

            pdf.validation_status = "RED"

            pdf.validation_reason = \
                "Unable to validate salary"

            return pdf

        return pdf