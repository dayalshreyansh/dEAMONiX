"""
pdf_service.py
---------------

Handles all PDF processing.

Responsibilities
----------------
1. Open PDF files.
2. Extract first page.
3. Convert PDF page to OpenCV image.
4. Extract native text.
5. Return structured PDF data.
"""

from dataclasses import dataclass

import cv2
import fitz
import numpy as np


@dataclass
class PDFData:
    pdf_document: fitz.Document
    image: np.ndarray
    text: str


class PDFService:

    @staticmethod
    def load(pdf_path: str) -> PDFData:
        """
        Load a PDF and prepare it for the AI pipeline.
        """

        pdf = fitz.open(pdf_path)

        page = pdf[0]

        pix = page.get_pixmap()

        image = np.frombuffer(
            pix.samples,
            dtype=np.uint8
        ).reshape(
            pix.h,
            pix.w,
            pix.n
        )

        # Convert RGB/RGBA into OpenCV's BGR format
        if pix.n == 3:
            image = cv2.cvtColor(
                image,
                cv2.COLOR_RGB2BGR
            )

        elif pix.n == 4:
            image = cv2.cvtColor(
                image,
                cv2.COLOR_RGBA2BGR
            )

        text = page.get_text("text").strip()

        return PDFData(
            pdf_document=pdf,
            image=image,
            text=text
        )