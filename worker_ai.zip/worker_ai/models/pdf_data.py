from dataclasses import dataclass, field
from typing import Dict, Optional

import fitz
import numpy as np


@dataclass
class PDFData:
    """
    Shared document object throughout the pipeline.
    """

    # ----------------------------
    # Original PDF Information
    # ----------------------------

    pdf_document: fitz.Document
    image: np.ndarray
    text: str
    metadata: Dict
    page_count: int

    # ----------------------------
    # OCR Results
    # ----------------------------

    ocr_text: str = ""

    # ----------------------------
    # AI Classification
    # ----------------------------

    document_type: str = "UNKNOWN"
    classification_confidence: float = 0.0

    # ----------------------------
    # Extracted Fields
    # ----------------------------

    extracted_fields: Dict = field(default_factory=dict)

    # ----------------------------
    # Metadata Analysis
    # ----------------------------

    metadata_status: str = "UNKNOWN"
    metadata_reason: str = ""

    # ----------------------------
    # Mathematical Validation
    # ----------------------------

    validation_status: str = "UNKNOWN"
    validation_reason: str = ""

    # ----------------------------
    # Fraud Detection
    # ----------------------------

    tamper_score: float = 0.0
    heatmap_path: Optional[str] = None

    # ----------------------------
    # Final Risk Assessment
    # ----------------------------

    risk_matrix: str = "UNKNOWN"

    final_status: str = "PROCESSING"

    credit_score: int = 0