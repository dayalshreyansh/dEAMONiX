"""
main.py

Main orchestration worker.

This file coordinates every service.

It DOES NOT contain business logic.
"""

import json
import time

from database import Database
from storage import Storage
from queue_manager import QueueManager

from services.pdf_service import PDFService
from services.ocr_service import OCRService
from services.classifier_service import ClassifierService
from services.extractor_service import ExtractorService
from services.validation_service import ValidationService
from services.tamper_service import TamperService

from services.risk_service import RiskService


pdf_service = PDFService()
ocr_service = OCRService()
classifier_service = ClassifierService()
extractor_service = ExtractorService()
validation_service = ValidationService()
tamper_service = TamperService()
risk_service = RiskService()


storage = Storage()
queue = QueueManager()


print("🚀 AI Underwriter Worker Started")


while True:

    try:

        job = queue.consume()

        if job is None:
            continue

        application_id = job["applicationId"]

        print(f"\nProcessing {application_id}")

        connection = Database.get_connection()

        cursor = connection.cursor()

        cursor.execute(
            """
            SELECT id,object_key
            FROM forensic_jobs
            WHERE application_id=%s
            AND status='QUEUED'
            """,
            (application_id,)
        )

        jobs = cursor.fetchall()

        for row in jobs:

            job_id = row["id"]

            object_key = row["object_key"]

            print(f"\nProcessing Job {job_id}")

            local_pdf = storage.download(object_key)

            pdf = pdf_service.load(local_pdf)

            pdf = ocr_service.process(pdf)

            pdf = classifier_service.process(pdf)

            pdf = extractor_service.process(pdf)

            pdf = validation_service.process(pdf)

            pdf = tamper_service.process(pdf)

            proof_key = storage.upload_proof(
                pdf.heatmap_path
            )

            cursor.execute(
                """
                UPDATE forensic_jobs

                SET

                status='COMPLETED',

                inferred_document_type=%s,

                proof_url=%s,

                math_status=%s,

                math_analysis_log=%s,

                visual_tamper_score=%s

                WHERE id=%s
                """,
                (
                    pdf.document_type,

                    proof_key,

                    pdf.validation_status,

                    pdf.validation_reason,

                    pdf.tamper_score,

                    job_id
                )
            )

            connection.commit()

        risk_service.evaluate(
            cursor,
            application_id
        )

        connection.commit()

        connection.close()

        queue.publish_result(
            application_id,
            final_status,
            final_risk_matrix,
            final_credit_score
        )

    except Exception as e:

        print(e)

        time.sleep(2)